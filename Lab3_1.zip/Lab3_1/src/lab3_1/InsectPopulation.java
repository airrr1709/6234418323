
package lab3_1;


public class InsectPopulation {

   private double balance;
   public InsectPopulation(double num){
       balance = num;
   }
   public void breed(){
       balance = balance*2;
    }
   public void spray(){
       balance = balance*0.9;
   }
   public double getNumInsect(){
       return balance;
   }
    
}
