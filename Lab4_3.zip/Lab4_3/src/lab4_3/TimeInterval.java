
package lab4_3;


public class TimeInterval {

    private int initialHour;
    private int finalHour;
    private int hours;
    private int minutes;
    public TimeInterval(int aninitialHour,int anfinalHour) {
        initialHour = aninitialHour;
        finalHour = anfinalHour;
    }

    public int getInitialHour(){
        return initialHour;
    }
    public int getFinalHour(){
        return finalHour;
    }
    public int getHours(){
        int start = (((int) Math.ceil(initialHour/100))*60)+(initialHour%100);
        int end = (((int) Math.ceil(finalHour/100))*60)+(finalHour%100);
        hours = (int) Math.ceil((end - start)/60);
        return hours;
    }
    public int getMinutes(){
        minutes = 60-Math.abs(((int) Math.ceil(finalHour%100))-((int) Math.ceil(initialHour%100)));
        return minutes;
    }
    
}
