
package lab4_3;


public class TimeInterval {

    private int initialHour;
    private int finalHour;
    private int hours;
    private int minutes;
    public TimeInterval(int aninitialHour,int anfinalHour) {
        initialHour = aninitialHour;
        finalHour = anfinalHour;
    }

    public int getHours(){
        int start = (((int) Math.ceil(initialHour/100))*60)+(initialHour%100);
        int end = (((int) Math.ceil(finalHour/100))*60)+(finalHour%100);
        hours = (int) Math.ceil((end - start)/60);
        return hours;
    }
    public int getMinutes(){
        int start = (((int) Math.ceil(initialHour/100))*60)+(initialHour%100);
        int end = (((int) Math.ceil(finalHour/100))*60)+(finalHour%100);
        hours = (int) Math.ceil((end - start)/60);
        minutes = (((int) Math.floor(finalHour%100))-((int) Math.floor(initialHour%100)));
        if (minutes == 0)
        {
            return minutes;
        }
        else if (minutes < 60 && hours == 0)
        {
            if (minutes < 0)
                minutes = 60-Math.abs(minutes);
                return minutes;
        }
        else {
            return Math.abs(minutes);
        }
        
    }
    
}
