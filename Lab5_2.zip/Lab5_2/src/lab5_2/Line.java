
package lab5_2;
import java.awt.geom.Point2D;

public class Line {
    
    public double m ;
    public double b ;
    public double x ;
    boolean NoM = false ;
    
    public Line(double x, double y, double m)
    {
        this.b = ((-m)*x)+y ;
        this.m = m ;
        this.x = Double.NaN ;
    }
    public Line(double x1, double y1, double x2, double y2)
    {
        this.m = (y1-y2)/(x1-x2);
        this.b = ((-this.m)*x1)+y1 ;
        this.x = Double.NaN ;
    }
    public Line(double m, double b)
    {
        this.m = m ;
        this.b = b ;
        this.x = Double.NaN ;
    }
    public Line(double a)
    {
        this.x = a ;
        this.b = Double.NaN ;
        this.m = Double.NaN ;
        NoM = true ;
    }
    
    public boolean isParallel(Line line)
    {
        String s1 = Double.toString(line.m);
        String s2 = Double.toString(this.m);
        return s1.equals(s2) ; 
        
    }
    public boolean equals(Line line)
    {
        String s1 = Double.toString(line.m);
        String s2 = Double.toString(this.m);
        String s3 = Double.toString(line.b);
        String s4 = Double.toString(this.b);
        return (s1.equals(s2) && s3.equals(s4)) ;
    }
    public boolean isIntersect(Line line)
    {
        return !(Line.this.isParallel(line)) ;
    }
    public Point2D.Double getIntersectionpoint(Line line)
    {
        double x_intersection = 0.0 ;
        double y_intersection = 0.0 ;
        boolean check = true ;
        
        if(this.NoM){
            x_intersection = this.x ;
            y_intersection = (line.m*x_intersection)+line.b;
            check = false ;
        }
        if(line.NoM){
            x_intersection = line.x ;
            y_intersection = (this.m*x_intersection)+this.b;
            check = false ;
        }
        if(check){
            x_intersection = (line.b-this.b)/(this.m-line.m);
            y_intersection = (this.m*x_intersection)+this.b;
        }
        
        return new Point2D.Double(x_intersection,y_intersection);
    }
    
}
