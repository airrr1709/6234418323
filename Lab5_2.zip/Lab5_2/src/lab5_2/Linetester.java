
package lab5_2;


public class Linetester {
    public static void main(String[] args) {
        Line l1 = new Line(3,5) ;
        Line l2 = new Line(5) ;
        System.out.println("Are two lines equals?: "+l1.equals(l2)) ;
        System.out.println("Are two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        if(l1.isIntersect(l2))
        {
            System.out.println("Point of intersection: "+l1.getIntersectionpoint(l2).getX()+","+l1.getIntersectionpoint(l2).getY());
        }
    }
}
