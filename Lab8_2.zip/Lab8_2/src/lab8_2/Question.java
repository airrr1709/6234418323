
package lab8_2;


public class Question {
    protected String text;
    protected String answer;
    public Question()
    {
        text = null ;
        answer = null ;
    }
    
    public Question(String Message)
    {
        text = Message ;
    }
    
    public void setText(String ques)
    {
        text = ques ;
    }
    public void setAnswer(String ans)
    {
        answer = ans ;
    }
    public String getText()
    {
        return text ;
    }
    
    public String getAnswer()
    {
        return answer ;
    }
    public boolean checkAnswer(String response)
    {
        return answer.equals(response);
    }
    public void display()
    {
        System.out.println(text);
    }
}
