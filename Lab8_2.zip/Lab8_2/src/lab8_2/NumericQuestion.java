
package lab8_2;

public class NumericQuestion extends Question {
    public NumericQuestion(String message)
    {
        super.setText(message);
    }
    @Override
    public boolean checkAnswer(String respone)
    {
        double answer1 = Double.parseDouble(answer);
        double respone1 = Double.parseDouble(respone);
        return Math.abs(answer1-respone1)<0.01;
    }
    
}
