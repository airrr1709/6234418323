
package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question {
    ArrayList<String> choices = new ArrayList<String>();;
    
    public ChoiceQuestion(String message)
    {
        super.setText(message);
    }
    
    public void addChoice(String choice, boolean correct)
    {
        choices.add(""+(choices.size()+1)+": "+choice) ;
        if(correct)
        {
            super.setAnswer(Integer.toString(choices.size()));
        }
    }
    
    @Override
    public void display()
    {
        System.out.println(super.getText());
        for(int i = 0 ; i < choices.size() ; i++)
        {
            System.out.println(choices.get(i));
        }
    }
    
    @Override
    public boolean checkAnswer(String response)
    {
        return response.equals(super.getAnswer()) ;
    }
    
}
