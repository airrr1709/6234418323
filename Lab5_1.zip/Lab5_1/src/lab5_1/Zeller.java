
package lab5_1;

import java.util.Scanner;

public class Zeller {
    private static int dayOfMonth;
    private static int month;
    private static int year;
    private static int h,q,m,j,k ;
    
    public Zeller(int d,int m,int y)
    {
        dayOfMonth = d;
        month = m;
        year = y;
    }
    public enum Day {
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        public final String dayOfWeek;
        private Day(String day)
        {
            this.dayOfWeek = day;
        }
        
        public static Day getDayOfWeek()
        {
            q = dayOfMonth;
            m = month;
            if (m==1)
            {
                year = year - 1 ;
                m = 13;
            }
            if (m==2)
            {
                year = year - 1 ;
                m = 14;
            }
            j = year/100;
            k = year%100;
            h = (q+(((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j)))%7;
            Day dayword = Day.SUNDAY;
            switch (h) {
                case 0:
                    dayword = Day.SATURDAY;
                    break;
                case 1:
                    dayword = Day.SUNDAY;
                    break;
                case 2:
                    dayword = Day.MONDAY;
                    break;
                case 3:
                    dayword = Day.TUESDAY;
                    break;
                case 4:
                    dayword = Day.WEDNESDAY;
                    break;
                case 5:
                    dayword = Day.THURSDAY;
                    break;
                case 6:
                    dayword = Day.FRIDAY;
                    break;
                default:
                    break;
            }
            return dayword;
        }
}
public static void main(String[] arg){
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter year (e.g,2012): ");
    int years = sc.nextInt();
    System.out.print("Enter month (1-12): ");
    int months = sc.nextInt();
    System.out.print("Enter day of month (1-31): ");
    int days = sc.nextInt();
    Zeller zeller = new Zeller(days,months,years);
    Day tester = Day.getDayOfWeek();
    System.out.println("Day of the week is "+tester.dayOfWeek);
        
}
}