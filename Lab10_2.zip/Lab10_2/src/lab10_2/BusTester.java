
package lab10_2;

import java.util.ArrayList;


public class BusTester {
    public static void main (String[] args){
        ArrayList<Bus> arr = new ArrayList<Bus>(2);
        arr.add(new Hybrid (150,1,600,45,1.2));
        arr.add(new CNGBus (50,1,200,2));
        for (Bus i : arr)
        {
            if(i instanceof Hybrid){
                Hybrid j = (Hybrid) i;
                System.out.println("ID: "+i.getID());
                System.out.println("Emission Tier: "+j.getEmissionTier());
                System.out.println("Accel: "+j.getAccel());
            }   
            else if(i instanceof CNGBus){
                CNGBus j = (CNGBus) i;
                System.out.println("ID: "+i.getID());
                System.out.println("Emission Tier: "+j.getEmissionTier());
                System.out.println("Accel: "+j.getAccel());
            }  
        
        }
    }
}
