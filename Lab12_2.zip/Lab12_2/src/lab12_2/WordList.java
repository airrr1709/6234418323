
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class WordList {

    public static void main(String[] args) {
        ArrayList<String> wordlist = new ArrayList<>();
        Scanner in = null;
        try {
            File f = new File("wordlist.txt");
            in = new Scanner(f);
        
            while(in.hasNextLine()){
                wordlist.add(in.nextLine());
            }
            in.close();
        }
        catch(FileNotFoundException e) {
            
            System.out.println("Error :");
            e.printStackTrace();
        
        } 
        System.out.print("Enter a sentence: ");
        Scanner sc = new Scanner(System.in);
        String[] text = sc.nextLine().split("\\s"); 
       
        String wordchoose = "";
        System.out.println("Words not contained:");
        for(int i = 2 ; i < text.length ; i++){
             if(!(wordlist.contains(text[i]))){
                 wordchoose += text[i];
             }
          
        }
        if (!"".equals(wordchoose)){
                System.out.println(wordchoose);
        }
        else{
            System.out.println("N/A");
        }

    }
    
}
