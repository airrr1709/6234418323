
package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    ArrayList<String> listOfsongs = new ArrayList<>(); 
    @Override
    public void enqueue (Object o ){
        listOfsongs.add((String) o);
        System.out.println(listOfsongs.get(listOfsongs.size()-1)+" is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing "+listOfsongs.get(0));
        listOfsongs.remove(0);
    }
    
}
