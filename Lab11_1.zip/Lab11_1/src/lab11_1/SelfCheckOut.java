
package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    ArrayList<Product> listOfgoods = new ArrayList<>(); 
    double amount = 0;
    @Override
    public void enqueue ( Object o){
         listOfgoods.add((Product) o);
        System.out.println(listOfgoods.get(listOfgoods.size()-1).getName()+"is added in queue");
    }
    @Override
    public void dequeue (){
        amount += listOfgoods.get(0).getPrice();
        listOfgoods.remove(0);
    }
    public double getAmount(){
        return amount;
    }

}
