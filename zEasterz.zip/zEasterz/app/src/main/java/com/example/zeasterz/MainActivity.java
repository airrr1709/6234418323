package com.example.zeasterz;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends Activity {
    public static final String EXTRA_MESSAGE = "com.example.easterday.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("My new title");
        //TextBox
        final EditText textBox = (EditText) findViewById(R.id.Textbox);
        //Submit Button
        final Button submit = (Button) findViewById(R.id.button);

        submit.setOnClickListener((v) -> {
                    if (textBox.getText().toString().trim().equals(""))
                        textBox.setError("Please enter year!!");
                    else {
                        easter easter = new easter(Integer.parseInt(textBox.getText().toString()));
                        easter.CalculateEaster();
                        Intent i = new Intent(getApplicationContext(), Main2Activity.class);
                        i.putExtra("day", String.valueOf(easter.getDay()));
                        i.putExtra("month", String.valueOf(easter.getYear()));
                        EditText editText = (EditText) findViewById(R.id.Textbox);
                        String message = editText.getText().toString();
                        i.putExtra(EXTRA_MESSAGE, message);
                        startActivity(i);
                    }
                }
        );
    }
}
