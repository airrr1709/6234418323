package com.example.zeasterz;

public class easter {
    public int y,a,b,c,d,e,g,h,j,k,m,r,n,p ;
    public String textInput ;

    public easter(int Year)
    {
        y = Year ;
    }

    public void CalculateEaster()
    {
        a = y%19 ;
        b = y/100 ;
        c = y%100 ;
        d = b/4 ;
        e = b%4 ;
        g = (8*b + 13)/25 ;
        h = (19*a+b-d-g+15)%30;
        j = c /4 ;
        k = c%4 ;
        m = (a+11*h)/319 ;
        r = (2*e+2*j-k-h+m+32)%7 ;
        n = (h-m+r+90)/25 ;
        p = (h-m+r+n+19)%32 ;
    }

    public String getDay()
    {
        String easterDay = Integer.toString(p);
        return easterDay ;
    }


    public String getYear()
    {
        String month = Integer.toString(n) ;
        if(month.equals("1"))
        {
            textInput = "January";
        }
        if(month.equals("2"))
        {
            textInput = "February";
        }
        if(month.equals("3"))
        {
            textInput = "March";
        }
        if(month.equals("4"))
        {
            textInput = "April";
        }
        if(month.equals("5"))
        {
            textInput = "May";
        }
        if(month.equals("6"))
        {
            textInput = "June";
        }
        if(month.equals("7"))
        {
            textInput = "July";
        }
        if(month.equals("8"))
        {
            textInput = "August";
        }
        if(month.equals("9"))
        {
            textInput = "September";
        }
        if(month.equals("10"))
        {
            textInput = "October";
        }
        if(month.equals("11"))
        {
            textInput = "November";
        }
        if(month.equals("12"))
        {
            textInput = "December";
        }
        return textInput ;

    }

}
