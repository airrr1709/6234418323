
package lab12_3;


public class TransactionRecord {
    private int acctNum;
    private double amount;
    public TransactionRecord(int accountNumber,double transAmount){
        acctNum = accountNumber;
        amount = transAmount;
    }
    public void setAccNo(int accNo){
        acctNum = accNo;
    }
    public int getAccountNo(){
        return acctNum;
    }
    public void setTransAmount(double transAmount){
        amount = transAmount;
    }
    public double getTransAmount(){
        return amount;
    }
    
}
