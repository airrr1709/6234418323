
package lab12_3;

import java.io.File;
import java.util.ArrayList;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
public class FileMatch {
    public static void main(String[] args) throws Exception {
        ArrayList<AccountRecord> acctRec = new ArrayList<>();
        ArrayList<TransactionRecord> transRec = new ArrayList<>();
        File acctFile = new File("master.txt");
        File transFile = new File("trans.txt");
        try (Scanner in1 = new Scanner(acctFile);){
            while(in1.hasNextLine()) {
                String[] ac = in1.nextLine().split("\\s");
                AccountRecord acct = new AccountRecord(Integer.parseInt(ac[0]),ac[1]+" "+ac[2],Double.parseDouble(ac[3]));
                acctRec.add(acct);
            }
            in1.close();
        }catch(IOException e) {
            e.printStackTrace();
        }
        try (Scanner in2 = new Scanner(transFile);) {
            while(in2.hasNextLine()) {
                String[] tr = in2.nextLine().split("\\s");
                TransactionRecord trans = new TransactionRecord(Integer.parseInt(tr[0]),Double.parseDouble(tr[1]));
                transRec.add(trans);
            }
            in2.close();
        }catch(IOException e) {
            e.printStackTrace();
        }
        
        for(int i=0; i<acctRec.size() ; i++) {
            for(int j=0; j<transRec.size();j++){
                acctRec.get(i).combine(transRec.get(j));
            }
        
        }

        String name;
        int AccNo;
        double Balance;
        int Tscnt;
        double allBalance=0 ;
        int cntNottrans=0 ;
        int accCnt =0 ;
        
        try {
            RandomAccessFile master = new RandomAccessFile("newMaster.dat", "rw");
            for(int i=0;i<acctRec.size();i++){
                name = acctRec.get(i).getName() ;
                AccNo = acctRec.get(i).getAcctNo() ;
                Balance = acctRec.get(i).getBalance() ;
                Tscnt = acctRec.get(i).getTransCnt();
                master.writeInt(AccNo);
                while(name.length() < 30) {
                    name += " " ;
                }
                master.writeChars(name);
                master.writeDouble(Balance);
                master.writeInt(Tscnt);
                master.writeChar('\n');
                    
                }
                master.seek(0);
            } catch(IOException e) {
                e.printStackTrace();
            }

        try {
            
            RandomAccessFile master = new RandomAccessFile("newMaster.dat", "r");
    
            for(int i=0;i<acctRec.size();i++) {
            
                master.seek(master.getFilePointer()+64); 
                allBalance += master.readDouble() ; 
                if(master.readInt() == 0){cntNottrans++;} 
                accCnt++; 
                master.seek(master.getFilePointer()+2);
            }

        } catch(IOException ex) {
            ex.printStackTrace();
        }
        
        System.out.println("Total Account Record : "+accCnt);
        System.out.println("Total Balance : "+allBalance);
        System.out.println("No transaction : "+cntNottrans+" account.");
    }
    

}

 