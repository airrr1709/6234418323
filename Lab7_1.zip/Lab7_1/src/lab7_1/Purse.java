
package lab7_1;
import java.util.ArrayList;

public class Purse {
    private ArrayList<String> purse;
    
    public Purse()
    {
        purse = new ArrayList<String>();
        
    }
    
    public void addCoin(String coinName)
    {
        purse.add(coinName);
    }
    public String toString()
    {
        String output = new String ("");
        for (int i =0 ; i < purse.size() ; i++)
        {
            output = output + purse.get(i);
        }
        return output;
    }
    public ArrayList<String> reverse()
    {
        ArrayList<String> purse2 = new ArrayList<String>();
        for(int i = purse.size()-1;i>=0;i--)
        {
            purse2.add(purse.get(i));
        }
        return purse2;
    }
    public void transfer(Purse other)
    {
        ArrayList<String> purse2 = new ArrayList<String>();
        for (int i = 0;i< purse.size();i++)
        {
            purse2.add(purse.get(i));
        }
    }
    public boolean sameContents(Purse other)
    {
        boolean done = true;
        
        for(int i = 0 ; i < purse.size();i++)
        {
            if (other.purse.get(i)!=(this.purse.get(i)))
            {
                done = false;
                break;
            }
        }
        return done;
    }
    public boolean sameCoins(Purse other)
    {
       boolean ch =true;
        if(other.purse.size()!= purse.size()) ch =false;
        else for(int i = 0 ; i < purse.size() ; i++)
        {
            int coin1 = 0;
            int coin2 = 0;
            for(int j = 0 ; j < purse.size() ; j++)
            {
                if(purse.get(i)==purse.get(j))
                    coin1++;
                if(purse.get(i)==other.purse.get(j))
                    coin2++;
            }
            if(coin1 != coin2)
            {
                ch = false;
                break;
            }
        }
        return ch; 
    }
    public static void main(String[] args)
    {
        Purse a = new Purse();
        Purse b = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Nickel");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        b.addCoin("Quarter");
        b.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Nickel");
        a.reverse();
        System.out.println("Same coins: "+a.sameCoins(b));
                
        
        
    }

    
    
}

    
