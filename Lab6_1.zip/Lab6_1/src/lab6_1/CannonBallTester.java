
package lab6_1;

public class CannonBallTester {
    public static void main(String[] arsg){
        CannonBall ball = new CannonBall(100);
        ball.simulatedFlight();
        Double time = ball.getSimulatedTime();
        System.out.printf("Final distance: %.3f Total time: %.2f\n"
                + "Distance from calculus equation: %.3f",
                ball.getSimulatedDistance(),time,ball.calculusFlight(time));
        
    }
}
