package com.example.easterday;

public class EasterDay {

    public int y,a,b,c,d,e,g,h,j,k,m,r,n,p ;
    public String text ;

    public EasterDay(int Year)
    {
        y = Year ;
    }

    public void calculation()
    {
        a = y%19 ;
        b = y/100 ;
        c = y%100 ;
        d = b/4 ;
        e = b%4 ;
        g = (8*b + 13)/25 ;
        h = (19*a+b-d-g+15)%30;
        j = c /4 ;
        k = c%4 ;
        m = (a+11*h)/319 ;
        r = (2*e+2*j-k-h+m+32)%7 ;
        n = (h-m+r+90)/25 ;
        p = (h-m+r+n+19)%32 ;
    }

    public String getDay()
    {
        String D = Integer.toString(p);
        return D ;
    }


    public String getYear()
    {
        String year = Integer.toString(n) ;
        if(year.equals("1"))
        {
            text = "January";
        }
        if(year.equals("2"))
        {
            text = "February";
        }
        if(year.equals("3"))
        {
            text = "March";
        }
        if(year.equals("4"))
        {
            text = "April";
        }
        if(year.equals("5"))
        {
            text = "May";
        }
        if(year.equals("6"))
        {
            text = "June";
        }
        if(year.equals("7"))
        {
            text = "July";
        }
        if(year.equals("8"))
        {
            text = "August";
        }
        if(year.equals("9"))
        {
            text = "September";
        }
        if(year.equals("10"))
        {
            text = "October";
        }
        if(year.equals("11"))
        {
            text = "November";
        }
        if(year.equals("12"))
        {
            text = "December";
        }
        return text ;

    }

}
