
package lab3_3;


public class CashRegister {
    public double tax ;
    public double price ;
    public double balance ;
    public double change;
    public double alltax;
    
    public CashRegister(double taxrate)
    {
        tax = taxrate ;
    }
    
    public void enterPayment(double money)
    {
        
        balance = balance + money ;
    }
    
    public void recordPurchase(double cost)
    {
        price = price + cost ;
    } 
    
    public void recordTaxablePurchase(double cost)
    {
        price = price + cost + (cost*tax/100.0) ;
        alltax = alltax + (cost*tax/100.0) ;
    }
    
    public double getTotalTax(){
        return alltax ;
    }
    
    public double giveChange()
    {
        change = balance - price ;
        change = (Math.round(change*10.0))/10.0;
        return change ;
    }
}
