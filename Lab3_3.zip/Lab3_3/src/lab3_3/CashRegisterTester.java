
package lab3_3;

public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister cash = new CashRegister(7);
        cash.enterPayment(100);
        cash.recordPurchase(50);
        cash.recordPurchase(10);
        cash.recordTaxablePurchase(20);
        System.out.println("Your change is "+cash.giveChange());
    }
        
}
