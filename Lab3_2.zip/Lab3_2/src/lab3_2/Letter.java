
package lab3_2;


public class Letter {

    private String writefrom;
    private String writeto;
    private String message = "";
    public Letter(String from, String to){
        writefrom = from +":"+"\n";
        writeto = "\n" + to ;
    }
    public void addLine(String line){
        message = message + line + "\n"  ;
    }
    public String getText(){
        return writefrom +"\n"+ message +"\n"+"Sincerely,"+"\n"+ writeto;
    }
    
}
