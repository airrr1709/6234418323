
package lab9_1;

import java.util.ArrayList ;
import java.lang.String ;

import java.util.ArrayList;

public class Order {
    
    public static int cntOrder = 0 ;
    private int id ;
    private Customer c ;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    
    public Order(Customer c)
    {
        this.c = c ;
    }
    
    public void addPizza(Pizza piz)
    {
        p.add(piz) ;
    }
    
    public String getOrderDetail()
    {
        cntOrder += 1 ;
        this.id = cntOrder ;
        
        String orderDetail = "Order id : "+this.id+"\n"+c.toString();
        double totalPrice = 0;
        for(int i = 0;i < p.size();i++)
        {
            orderDetail += "\n"+p.get(i).toString() ;
            totalPrice += p.get(i).getPrice() ;
        }
        orderDetail += "\nTotal pieces : "+p.size() ;
        if(c instanceof GoldCustomer)
        {
            totalPrice = (totalPrice*(100.0-((GoldCustomer)c).getDiscount())/100.0) ; 
        }
        orderDetail += "\nTotal cost : "+totalPrice ;
        return orderDetail ;
       
    }
    
    public double calculatePayment()
    {
        double totalPrice = 0;
        for(int i = 0;i < p.size();i++)
        {
            totalPrice += p.get(i).getPrice() ;
        }
        
        if(c instanceof GoldCustomer)
        {
            totalPrice = (totalPrice*(100.0-((GoldCustomer)c).getDiscount())/100.0) ; 
        }
        return totalPrice ;
    }
    
    
}

class Pizza {
    
    private String name ;
    private double price ;
    
    public Pizza(String name,double price)
    {
        this.name = name ;
        this.price = price ;
    }
    
    @Override
    public String toString()
    {
        return name+" price : "+price ;

    }
        
    public double getPrice()
    {
        return price ;
    }

}

class PizzaSpecial extends Pizza {
    
    private String special ;
    
    public PizzaSpecial(String name,double price,String special)
    {
        super(name,price) ;
        this.special = special ;
    }
    
    @Override
    public String toString()
    {
        return super.toString()+" special : "+special ;
    }
    
    @Override
    public double getPrice()
    {
        return super.getPrice() ;
    }
    
    
}

class Customer {
    
    private String name,tel ;
    
    public Customer(String name,String tel)
    {
        this.name = name ;
        this.tel = tel ;
    }
    
    @Override
    public String toString()
    {
        return name+" tel : "+tel ;
    }
    
}

class GoldCustomer extends Customer {
    
    private double discount ;
    
    public GoldCustomer(String name,String tel,double discount)
    {
        super(name,tel);
        this.discount = discount ;
    }
    
    @Override
    public String toString()
    {
        return super.toString()+" discount: "+discount ;
    }
    
    public double getDiscount()
    {
        return discount ;
    }
    
}
