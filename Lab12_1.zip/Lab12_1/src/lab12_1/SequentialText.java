
package lab12_1;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class SequentialText {

    public static void main(String[] args) throws Exception {
        int sum_chars = 0,sum_words = 0,sum_lines = 0;
        String sentence = null;
        boolean check = true;
        Scanner in = new Scanner(System.in);
        File f = new File("sequential_text.txt");
        if(f.exists()){
            System.out.println("File already exists,please change file name");
        }
        else{
            PrintWriter write = new PrintWriter(f);
        
            while (check) {
                sentence = in.nextLine();
                
                if(sentence.equals("quit")){
                    check = false;
                }
                else{
                    sum_lines +=1 ;
                    write.println(sentence);
                    String[] words = sentence.split("\\s");
                    sum_words += words.length;
                    sum_chars += sentence.length();
                }
            }
        
            System.out.println("Total characters : "+sum_chars);
            System.out.println("Total words : "+sum_words);
            System.out.println("Total lines : "+sum_lines);
            write.close();
        }
    }
    
}
