
package lab4_1;


public class SodaTester {
    public static void main(String[] arg){
        SodaCan soda = new SodaCan(15,5);
        System.out.println("Enter height: " + (int) soda.getHeight());
        System.out.println("Enter diameter: " + (int) soda.getDiameter());
        System.out.println("Volume: " + soda.getVolume());
        System.out.println("Surface area: " + soda.getSurfaceArea());
    }
}
