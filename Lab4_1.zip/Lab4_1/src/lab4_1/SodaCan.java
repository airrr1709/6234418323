
package lab4_1;

public class SodaCan {

    
    private float height;
    private float diameter;
    private float volume;
    private float surfacearea;
    public SodaCan(float height, float diameter){
        this.height = height;
        this.diameter = diameter;
    }
    public float getVolume(){
        float volume1 = (float) (Math.PI*(diameter/2)*(diameter/2)*height);
        float volume2 = Math.round(volume1*100);
        volume = volume2/100;
        return volume;
    }
    public float getSurfaceArea(){
        float areacircle = (float) (((Math.PI)*(diameter/2)*(diameter/2))*2);
        float sidearea = (float) (2*((Math.PI)*(diameter/2)*height));
        float surfacearea1 = areacircle + sidearea;
        float surfacearea2 = Math.round(surfacearea1*100);
        surfacearea = surfacearea2/100;
        return surfacearea;
    }
    public float getHeight(){
        return height;
    }
   
    public float getDiameter(){
        return diameter;
    }
    
}
