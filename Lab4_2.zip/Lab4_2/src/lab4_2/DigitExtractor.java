
package lab4_2;

public class DigitExtractor {

    private int numberint;
    private int intout;
    public DigitExtractor(int anInteger) {
        numberint = anInteger;
    }
    public int nextDigit(){
        intout = numberint%10;
        numberint = numberint/10;
        return intout;
    }
}
