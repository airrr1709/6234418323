
package lab9_2;

/**
 *
 * @author ASUS
 */
public abstract class Taylor {
    private int k ;
    private double x ;
    
    public int factorial(int n)
    {
        int answer = 1 ;
        for(int i = 1 ; i <= n ; i++) {
            answer = answer * i ;
        }
        return answer ;
    }
    
    public void setlter(int k) 
    {
        this.k = k ;
    }
    
    public int getlter()
    {
        return k ;
    }
    
    public void setValue(double x)
    {
        this.x = x ;
    }
    
    public double getValue()
    {
        return x ;
    }
    
    public abstract void printValue();
    
    public abstract double getApprox() ;
    
}

class expo extends Taylor {
    
    public expo(int k,double x)
    {
        super.setValue(x);
        super.setlter(k);
    }
    
    @Override
    public double getApprox()
    {
        double summary = 0;
        
        for(int i=0;i <= super.getlter();i++ )
        {
            summary += ( ( Math.pow(super.getValue(),i) )/ (super.factorial(i)) ) ;
        }
        
        return summary ;
    }
    
    @Override
    public void printValue()
    {
        System.out.println("Value from Math.exp() is "+Math.exp(super.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
    
}

class sine extends Taylor{
    
    public sine(int k ,double x)
    {
        super.setValue(x);
        super.setlter(k);
    }
    
    @Override
    public double getApprox()
    {
        double approx = 0;
        
        for(int i=0;i <= super.getlter();i++ )
        {
            approx += ( ( Math.pow(-1,i)*Math.pow(super.getValue(), (2*i)+1))/ (super.factorial((2*i)+1)) ) ;
        }
        
        return approx ;
    }
    
    @Override
    public void printValue()
    {
        System.out.println("Value from Math.sine() is "+Math.sin(super.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
    
}

class cosine extends Taylor {
    
    public cosine(int k ,double x)
    {
        super.setValue(x);
        super.setlter(k);
    }
    
    @Override
    public double getApprox()
    {
        double summary = 0;
        
        for(int i=0;i <= super.getlter();i++ )
        {
            summary += ( ( Math.pow(-1,i)*Math.pow(super.getValue(), (2*i)))/ (super.factorial((2*i))) ) ;
        }
        
        return summary ;
    }
    
    @Override
    public void printValue()
    {
        System.out.println("Value from Math.cos() is "+Math.cos(super.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }

}

