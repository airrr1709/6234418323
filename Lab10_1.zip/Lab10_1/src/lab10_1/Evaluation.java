
package lab10_1;

public interface Evaluation {
    double evaluate();
    char grade(double point);
    
}
class Employee {
    private String name;
    private int salary;
    public Employee(String name){
        this.name = name;
    }
    public void setSalary(int salary){
        this.salary = salary;
    }
    
    @Override
    public String toString(){
        return name+"\nsalary = "+salary;
    }
}
class Secretary extends Employee implements Evaluation  {
    private int typingSpeed;
    private int score[];
    public Secretary(String name,int salary,int sc[],int typingSpeed){
        super(name);
        super.setSalary(salary);
        this.score = sc;
        this.typingSpeed = typingSpeed;
        
    }
    public double evaluate(){
        int sum = 0;
        for ( int i = 0; i < score.length ; i++)
        {
            sum = sum + score[i];
        }
        return sum;
    }
    public char grade(double sum){
        char grade = 'G';
        if (sum >= 90){
            super.setSalary(18000);
            grade = 'P';
        }
        else {
            grade = 'F';
        }
        return grade;
    }
    
}
class Subject implements Evaluation {
    private String subjName;
    private int score[];
    public Subject(String subjName,int score[]){
        this.subjName = subjName;
        this.score = score;
    }
    public double evaluate(){
        int sum = 0;
        for ( int i = 0 ; i < score.length;i++){
            sum = sum + score[i];
        }
        double average = sum/score.length;
        return average ;
    }
    public char grade(double average){
        char grade = 'G';
        if (average >= 70){
            grade = 'P';
        }
        else{
            grade = 'F';
        }
        return grade;
    }
    public String toString(){
        return subjName;
    }
}